from django.apps import AppConfig


class AdministracionConfig(AppConfig):
    name = 'administracion'
