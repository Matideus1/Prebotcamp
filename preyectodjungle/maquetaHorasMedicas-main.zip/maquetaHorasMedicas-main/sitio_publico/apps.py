from django.apps import AppConfig


class SitioPublicoConfig(AppConfig):
    name = 'sitio_publico'
